module.load(header.id, player.charName:lower()..'/main')

chat.clear()
chat.add('lvxlol', {color = '#8b0000', bold = true,})
chat.print()