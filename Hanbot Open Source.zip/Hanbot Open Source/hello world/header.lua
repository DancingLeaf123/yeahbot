return {
  id = 'hello_world',
  name = 'Hello World',
  load = function()
    return true
  end,
}