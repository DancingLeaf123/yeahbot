-- https://www.colorhexa.com/

local hex = {
  electric_blue = '7df9ff',
  electric_lime = 'ccff00',
  electric_yellow = 'ccff00',
  cadmium_yellow = 'fff600',
  electric_indigo = '6f00ff',
  electric_violet = '8f00ff', 
}

return hex