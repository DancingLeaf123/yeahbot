return {
  id = 'menu_example',
  name = 'Menu Example',
  load = function()
    return true
  end,
}